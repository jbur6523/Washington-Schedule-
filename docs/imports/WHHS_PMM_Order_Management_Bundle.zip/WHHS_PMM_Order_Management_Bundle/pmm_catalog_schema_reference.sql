-- REFERENCE SCHEMA ONLY
-- Codex must inspect the existing repository, choose the next unused migration
-- prefix, mirror existing RLS/policy patterns, and adapt existing order table names.
-- Do not run this file blindly against production.

create table if not exists public.pmm_catalog (
  id uuid primary key default gen_random_uuid(),
  pmm_number text not null unique
    check (pmm_number ~ '^[0-9]+$'),
  item_name text not null,
  category text,
  vendor_catalog_number text,
  vendor text,
  catalog_status text not null default 'active'
    check (catalog_status in ('active', 'discontinued', 'do_not_use')),
  is_orderable boolean not null default true,
  review_required boolean not null default false,
  confidence text not null default 'high'
    check (confidence in ('high', 'medium', 'low')),
  alternate_descriptions text[] not null default array[]::text[],
  notes text,
  source_files text[] not null default array[]::text[],
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists pmm_catalog_item_name_idx
  on public.pmm_catalog using gin (to_tsvector('english', item_name));

-- Recommended normalized order-line shape. Replace `orders` and its key/type
-- with the actual existing Order Management table found in the repository.
--
-- create table public.order_items (
--   id uuid primary key default gen_random_uuid(),
--   order_id uuid not null references public.orders(id) on delete cascade,
--   line_type text not null check (line_type in ('pmm', 'non_catalog')),
--   pmm_number text references public.pmm_catalog(pmm_number),
--   item_name_snapshot text not null,
--   sort_order integer not null default 0,
--   created_at timestamptz not null default now(),
--   check (
--     (line_type = 'pmm' and pmm_number is not null) or
--     (line_type = 'non_catalog' and pmm_number is null)
--   )
-- );
--
-- create unique index order_items_unique_pmm_per_order
--   on public.order_items(order_id, pmm_number)
--   where line_type = 'pmm';
--
-- Add RLS and policies by copying the existing Order Management role model.
-- Do not alter authentication/session behavior.
