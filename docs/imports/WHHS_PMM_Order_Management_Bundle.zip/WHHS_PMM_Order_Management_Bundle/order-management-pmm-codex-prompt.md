# WHHS RT Schedule — Order Management PMM Catalog Upgrade

Use **High reasoning** for this phase because it includes schema, migrations,
server-side validation, role permissions, and multi-table order creation.

## Context

The existing WHHS RT Schedule application is a mobile-first Next.js /
TypeScript / Supabase application deployed on Vercel. Order Management already
supports creating and viewing supply orders with fields such as Req Number,
date/time, creator, notes, and an optional image.

This is a non-PHI respiratory operations workflow tool. It is not Epic,
clinical charting, or official medical documentation.

A PMM catalog bundle is supplied with this prompt:

- `pmm_catalog_seed.csv`
- `pmm_catalog_master.csv`
- `pmm_catalog_needs_review.csv`
- `pmm_catalog_master.json`
- `pmm_catalog_seed.sql`
- `pmm_catalog_schema_reference.sql`

The supplied catalog contains **186 unique PMM numbers** and
**169 resolved seed records**. Every PMM appears only once in the
master dataset. Do not import unresolved rows from the review file as active
catalog items.

## Non-negotiable guardrails

- **Do not rebuild the application or Order Management from scratch.**
- Inspect and extend the existing components, server actions/API routes, tables,
  migrations, RLS policies, and design system.
- **Do not perform a broad authentication or session rewrite.**
- Preserve the public `/login` route and all current Admin, Aide, Lead, Staff,
  Director, Command Center, and ICU access behavior.
- Do not weaken non-admin restrictions.
- Do not commit credentials, test passwords, staff emails, internal URLs, source
  photos, secrets, or tokens.
- Choose the **next unused migration prefix already consistent with the repo**.
  Do not rename or edit migrations that may already have been applied.
- Use `pmm_number` as **text**, not an integer.
- Preserve all current Order History, explicit Search Order, image, notes,
  View All/Load More, and mobile behavior unless this prompt explicitly changes
  it.

## Goal

Upgrade Create Order so an aide can enter PMM numbers, automatically resolve
them to item names, add manual non-catalog items, save normalized order lines,
and open a clean View Order screen containing the order date, PMM number, and
item name.

---

## Part A — Repository and schema inspection

Before changing code:

1. Locate the existing Order Management dashboard, Create Order form, Order
   History cards, View Order behavior, database table(s), server action/API
   route, types, validation, RLS policies, and tests.
2. Determine the actual order table name and primary-key type.
3. Determine which existing roles may create and view orders.
4. Review the migration directory and select the next unused timestamp/prefix.
5. Report any conflict between the supplied reference schema and the existing
   database before adapting it.

Do not assume the existing table is literally named `orders`.

---

## Part B — PMM catalog database

Create a normalized PMM catalog using the existing Supabase conventions.

Required logical fields:

- `id`
- `pmm_number` — text, required, unique
- `item_name` — text, required
- `category` — optional text
- `vendor_catalog_number` — optional text
- `vendor` — optional text
- `catalog_status` — `active`, `discontinued`, or `do_not_use`
- `is_orderable` — boolean
- `review_required` — boolean
- `confidence` — `high`, `medium`, or `low`
- `alternate_descriptions` — text array or equivalent
- `notes` — optional text
- timestamps

Seed the resolved rows from `pmm_catalog_seed.csv` or the supplied idempotent SQL
upsert. Do **not** seed rows whose master status is `unknown` or `review`.

Mirror the app's existing RLS and role-access pattern:

- Authorized Order Management users may read the PMM catalog.
- Only the existing appropriate admin/management path may modify catalog data.
- The browser must not receive service-role credentials.
- Do not solve catalog access by weakening unrelated policies.

Discontinued and do-not-use records should remain searchable for safety but
must not be orderable.

---

## Part C — Normalized order lines

Extend the existing order data model with a normalized child-line structure.
Adapt names and foreign-key types to the actual repository.

Each saved line must contain:

- parent order ID
- `line_type`: `pmm` or `non_catalog`
- nullable `pmm_number`
- `item_name_snapshot`
- `sort_order`
- timestamps

Rules:

- A PMM line references the catalog PMM and stores the resolved item-name
  snapshot.
- A non-catalog line has no fake PMM and stores the manually entered item name.
- The same PMM may appear only once within the same order.
- Preserve the user's original line order.
- Creating the parent order and all order lines must be atomic where the current
  architecture permits. A partial order must not remain if line creation fails.
- Validate PMMs and orderability again on the server. Do not trust client-only
  lookup results.
- Existing legacy orders without normalized lines must continue to render
  gracefully.

Do not remove current Req Number, notes, image, creator, or timestamp fields.

---

## Part D — Create Order form

Between the existing **Req Number** and **Notes** inputs, add:

**Label**

`PMM Numbers`

**Placeholder**

`1356, 978, 21592...`

**Compact helper**

`Enter PMM numbers separated by spaces or commas.`

The field is optional.

### Input normalization

Implement predictable mobile-friendly behavior:

1. When a user types a PMM token and presses Space, prevent an unnecessary
   literal space and append `, ` if the token does not already end in a comma.
2. Leading spaces, repeated spaces, or a space immediately after a comma must
   not create empty entries or repeated commas.
3. Accept pasted values separated by commas, spaces, semicolons, or line breaks.
4. On blur and before submit, normalize to a unique ordered array of numeric
   strings.
5. Preserve the first appearance of each PMM.
6. If the same PMM is entered twice, show one resolved line and a subtle
   duplicate-ignored message; do not create duplicate order lines.
7. Never coerce the values through JavaScript numbers.

Examples:

- `1356 978 21592` → `1356, 978, 21592`
- `1356, 978  21592,` → `1356, 978, 21592`
- `1356, 1356, 978` → two lines: `1356` and `978`

### Lookup display

As PMMs are normalized, show compact resolved rows/chips beneath the input:

- PMM number
- item name
- remove control
- clear status when relevant

States:

- Active match: normal resolved item.
- Discontinued/do-not-use match: clear red warning; cannot submit that line.
- Unknown PMM: `PMM #____ not found`; user can remove it or use Non-Catalog.
- Loading and lookup failures must have accessible, non-destructive states.

Do not silently save an unknown PMM or substitute a guessed item name.

---

## Part E — Non-Catalog items

Add a visible button near the PMM area:

`+ Non-Catalog Item`

Clicking it adds a manual item row.

Required:

- Item Name — required
- Remove control

Optional only if it fits the existing form cleanly:

- Quantity
- Item-specific note

Rules:

- Multiple non-catalog rows are allowed.
- Do not use `NONSTOCK`, `0`, or another fake value as the PMM number.
- At least one meaningful order component must exist before submission: a PMM
  line, a non-catalog line, or whatever legacy content currently makes an order
  valid. Preserve current validation rather than arbitrarily breaking it.
- Manual item names must be safely rendered as text, not HTML.

---

## Part F — Saving and error handling

On Create Order submit:

1. Normalize and de-duplicate PMMs.
2. Resolve them server-side.
3. Reject unknown, discontinued, and do-not-use PMM lines with a clear message.
4. Save the existing parent order.
5. Save PMM and non-catalog child lines with item-name snapshots and sort order.
6. Preserve current image upload behavior.
7. Show the existing success experience.
8. Prevent duplicate submissions from double taps using the app's current
   pending/disabled pattern.

If one part fails, show a useful error and avoid a partially created order.

---

## Part G — View Order

Every Order History result must expose a clear **View Order** action.

Use the existing modal/sheet pattern if one exists. Otherwise create an
accessible mobile-first dialog or bottom sheet.

Display:

- Order date and time, using the app's established America/Los_Angeles handling
- Req Number when present
- Created by
- **Catalog Items**
  - PMM #
  - Item Name
- **Non-Catalog Items**
  - Item Name
- Notes when present
- Existing image only when present; no placeholder image
- Existing full-size image interaction

The user specifically needs the viewable order to show:

- Date
- PMM #
- Item name

Preserve original line order. The modal must scroll fully on small phones and
must not cut off the last item.

Legacy orders with no child lines should still open and display their existing
information without crashing.

---

## Part H — Order History compatibility

Preserve these existing behaviors:

- Last seven orders shown by default
- View All / Load More at the bottom
- Search does not run while typing
- Explicit Search Order button activates when text is entered
- No placeholder image for orders with no image
- Clicking an existing image opens it full size
- Req Number remains optional
- Notes and image remain optional

Search should also match PMM number and resolved item-name snapshots if this can
be added without degrading the existing explicit-search behavior.

---

## Part I — Documentation

Add or update concise repository documentation covering:

- PMM catalog purpose and data source
- Why PMM numbers are text
- Catalog status behavior
- Order-line snapshot behavior
- How to add or update catalog rows safely
- How unresolved review rows are handled
- Rollback considerations
- Non-PHI reminder

Do not include credentials or source-photo contents.

---

## Validation

Run the repository's existing equivalents of:

- TypeScript typecheck
- lint
- unit/component tests
- production build
- migration validation
- database/RLS tests if present

Add focused tests for:

- PMM parsing and normalization
- comma insertion on Space
- mixed pasted separators
- de-duplication preserving first order
- catalog lookup states
- non-orderable PMM rejection
- server-side PMM validation
- normalized order-line creation
- View Order rendering
- legacy order rendering

Do not claim validation passed unless the command actually ran successfully.

---

## Manual acceptance tests

1. Create an order with no PMM field and confirm existing optional behavior still
   works.
2. Type `1356`, press Space, type `978`, press Space, and type `21592`.
   Confirm the field becomes `1356, 978, 21592`.
3. Paste `1356 978; 21592\n1356` and confirm three unique PMMs in first-seen
   order.
4. Confirm active PMMs display the correct item names from the catalog.
5. Enter an unknown PMM and confirm it is clearly unresolved and cannot be
   silently submitted.
6. Enter a discontinued/do-not-use PMM and confirm it is visible but blocked.
7. Add two Non-Catalog Item rows and save them without fake PMM values.
8. Confirm duplicate PMMs create only one order line.
9. Open View Order and confirm Date, PMM #, and Item Name appear.
10. Confirm Req Number, creator, notes, and image still behave as before.
11. Confirm a legacy order opens without an error.
12. Confirm Order History still defaults to seven and View All/Load More remains
    at the bottom.
13. Confirm explicit Search Order behavior remains unchanged.
14. Confirm the final item in a long order is reachable on a small mobile screen.
15. Confirm authorized Aide/Admin workflows work.
16. Confirm forbidden users remain forbidden.
17. Confirm `/login` remains public and unauthenticated users see login—not
    `Could not verify access`.
18. Confirm Admin and the existing non-admin test roles can still sign in.
19. Confirm no credentials, staff emails, internal URLs, or secrets appear in
    committed code, fixtures, screenshots, logs, or docs.

---

## Commit message

`feat(order-management): add PMM catalog and viewable order lines`

---

## Report back

Return:

1. Files changed
2. Migration filename and schema decisions
3. Number of PMM catalog rows seeded
4. How PMM parsing/de-duplication works
5. How unknown and inactive PMMs behave
6. How non-catalog lines are stored
7. How View Order was implemented
8. RLS/permission changes
9. Commands run and exact results
10. Manual tests completed
11. Screenshots or concise UI description
12. Commit hash
13. Remaining review items or risks
