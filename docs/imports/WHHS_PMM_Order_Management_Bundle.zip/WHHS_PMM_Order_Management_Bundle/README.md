# WHHS PMM Catalog and Order Management Update Bundle

Generated from the supplied PMM photo archive on 2026-07-15.

## Dataset summary

- **186 unique numeric PMM values**
- **169 resolved rows ready for database seeding**
- **161 active/orderable rows**
- **8 resolved inactive rows**
- **23 rows requiring review**
- **17 unresolved rows excluded from the SQL seed**

The master catalog contains each PMM number only once. Repeated appearances were
combined into one record with aliases, notes, and source filenames. A duplicate
PMM was not discarded merely because it appeared in multiple photos.

## Files

- `pmm_catalog_master.xlsx` — formatted workbook with summary, complete catalog,
  seed rows, and review queue.
- `pmm_catalog_master.csv` — all deduplicated PMM records.
- `pmm_catalog_seed.csv` — resolved records suitable for import.
- `pmm_catalog_needs_review.csv` — conflicts, unreadable item names, and active
  records with contradictory historical labels/statuses.
- `pmm_catalog_master.json` — structured version for code-based import.
- `pmm_catalog_schema_reference.sql` — reference schema; Codex must adapt it to
  the existing repository and RLS patterns.
- `pmm_catalog_seed.sql` — idempotent upsert of resolved catalog records.
- `order-management-pmm-codex-prompt.md` — implementation prompt.

## Important review behavior

Rows marked `active` and `review_required=true` have a strong current
eProcurement description but an older sheet contained a conflicting label or
status. They are included in the seed and remain visible in the review queue.

Rows marked `unknown` or `review` are not included in the seed SQL. They should
not become orderable until their item names are confirmed.

## Safety and implementation notes

- PMM numbers are text values, not integers, so leading zeroes remain possible.
- Do not treat `NONSTOCK` as a PMM number.
- Store a snapshot of the item name on every order line so historical orders do
  not change if a catalog description is edited later.
- Do not copy credentials, staff emails, internal URLs, or source-photo content
  into code, documentation, tests, screenshots, logs, or seed data.
- The photo-derived catalog should receive a final department review before a
  production pilot.
